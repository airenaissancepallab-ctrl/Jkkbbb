
import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  sanitizeHtml, 
  formRateLimiter, 
  securityMonitor,
  validateFormSecurity,
  SECURITY_CONFIG 
} from '@/lib/security';
import { sendToZapier } from '@/lib/zapier';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, Clock } from "lucide-react";

// Security-focused validation schema
const contactFormSchema = z.object({
  name: z.string()
    .min(2, "Name must be at least 2 characters")
    .max(SECURITY_CONFIG.MAX_NAME_LENGTH, `Name must be less than ${SECURITY_CONFIG.MAX_NAME_LENGTH} characters`)
    .regex(/^[a-zA-Z\s.'-]+$/, "Name can only contain letters, spaces, periods, apostrophes, and hyphens"),
  phone: z.string()
    .min(10, "Phone number must be at least 10 digits")
    .max(SECURITY_CONFIG.MAX_PHONE_LENGTH, `Phone number must be less than ${SECURITY_CONFIG.MAX_PHONE_LENGTH} digits`)
    .regex(/^[\+]?[0-9\s\-\(\)]+$/, "Invalid phone number format"),
  email: z.string()
    .email("Invalid email address")
    .max(SECURITY_CONFIG.MAX_EMAIL_LENGTH, `Email must be less than ${SECURITY_CONFIG.MAX_EMAIL_LENGTH} characters`),
  message: z.string()
    .min(10, "Message must be at least 10 characters")
    .max(SECURITY_CONFIG.MAX_MESSAGE_LENGTH, `Message must be less than ${SECURITY_CONFIG.MAX_MESSAGE_LENGTH} characters`)
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export const ContactForm = () => {
  const { toast } = useToast();
  const [rateLimitStatus, setRateLimitStatus] = useState(formRateLimiter.getStatus());
  
  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      message: "",
    },
  });

  // Update rate limit status every second
  useEffect(() => {
    const interval = setInterval(() => {
      setRateLimitStatus(formRateLimiter.getStatus());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (milliseconds: number): string => {
    const seconds = Math.ceil(milliseconds / 1000);
    if (seconds < 60) return `${seconds} seconds`;
    const minutes = Math.ceil(seconds / 60);
    return `${minutes} minutes`;
  };

  const onSubmit = async (data: ContactFormData) => {
    // Check rate limiting
    if (!formRateLimiter.canSubmit()) {
      const remainingTime = formRateLimiter.getRemainingTime();
      const timeString = formatTime(remainingTime);
      
      formRateLimiter.recordFailedAttempt();
      
      toast({
        variant: "destructive",
        title: "Rate Limit Exceeded",
        description: `Too many submissions. Please wait ${timeString} before trying again.`,
      });
      
      securityMonitor.logSecurityEvent('RATE_LIMIT_EXCEEDED', {
        remainingTime,
        userAgent: navigator.userAgent
      });
      
      return;
    }

    // Enhanced security validation
    const securityValidation = validateFormSecurity(data);
    
    if (!securityValidation.isValid) {
      toast({
        variant: "destructive",
        title: "Security Warning",
        description: "Your submission contains potentially harmful content. Please review and try again.",
      });
      
      formRateLimiter.recordFailedAttempt();
      return;
    }

    // Use sanitized data
    const sanitizedData = securityValidation.sanitizedData;

    // Log successful security validation
    securityMonitor.logSecurityEvent('FORM_SUBMISSION_SUCCESS', {
      formFields: Object.keys(sanitizedData),
      timestamp: new Date().toISOString()
    });

    // Send form data to Zapier webhook
    try {
      // Type assertion is safe here since validateFormSecurity preserves the form structure
      const formData: ContactFormData = {
        name: sanitizedData.name!,
        email: sanitizedData.email!,
        phone: sanitizedData.phone!,
        message: sanitizedData.message!,
      };
      
      await sendToZapier(formData as Required<ContactFormData>);
      
      toast({
        title: "Message Sent Successfully",
        description: "Thank you for your message. I'll get back to you soon!",
      });

      form.reset();
      formRateLimiter.reset(); // Reset on successful submission
    } catch (error) {
      console.error('Error sending message:', error);
      
      toast({
        variant: "destructive",
        title: "Failed to Send Message",
        description: error instanceof Error ? error.message : "Please check your webhook configuration and try again.",
      });
      
      formRateLimiter.recordFailedAttempt();
    }
  };

  return (
    <Card className="bg-card border-border shadow-elegant">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-emerald" />
          <CardTitle className="font-playfair text-2xl">Get in Touch</CardTitle>
        </div>
        <CardDescription>
          Reach out for legal discussions, academic collaboration, or professional opportunities.
          All submissions are secured with enterprise-grade protection.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Rate limit status indicator */}
        {rateLimitStatus.isBlocked && (
          <Alert className="mb-4 border-amber-500 bg-amber-50">
            <Clock className="h-4 w-4" />
            <AlertDescription>
              {rateLimitStatus.nextAttemptIn > 0 
                ? `Please wait ${formatTime(rateLimitStatus.nextAttemptIn)} before submitting again.`
                : `You have reached the submission limit. Please wait ${formatTime(formRateLimiter.getRemainingTime())}.`
              }
            </AlertDescription>
          </Alert>
        )}

        {/* Submission status */}
        {!rateLimitStatus.isBlocked && rateLimitStatus.attemptsRemaining < 5 && (
          <Alert className="mb-4 border-blue-500 bg-blue-50">
            <AlertDescription>
              {rateLimitStatus.attemptsRemaining} submission{rateLimitStatus.attemptsRemaining !== 1 ? 's' : ''} remaining in this session.
            </AlertDescription>
          </Alert>
        )}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Your full name" 
                        className="border-border"
                        {...field}
                        autoComplete="name"
                        disabled={rateLimitStatus.isBlocked}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="+91-XXXXXXXXXX" 
                        className="border-border"
                        {...field}
                        autoComplete="tel"
                        disabled={rateLimitStatus.isBlocked}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input 
                      type="email" 
                      placeholder="your.email@example.com" 
                      className="border-border"
                      {...field}
                      autoComplete="email"
                      disabled={rateLimitStatus.isBlocked}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Share your message or inquiry..." 
                      className="border-border min-h-[120px]"
                      {...field}
                      disabled={rateLimitStatus.isBlocked}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              variant="consultation" 
              size="lg" 
              className="w-full"
              disabled={form.formState.isSubmitting || rateLimitStatus.isBlocked}
            >
              {form.formState.isSubmitting ? "Sending..." : "Send Secure Message"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};
