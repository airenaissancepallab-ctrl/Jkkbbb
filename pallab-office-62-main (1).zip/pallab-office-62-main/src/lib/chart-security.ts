
/**
 * Security utilities for chart configurations
 * Prevents CSS injection through chart theme configurations
 */

/**
 * Allowed CSS color properties for chart themes
 * Only HSL values from our design system are permitted
 */
const ALLOWED_CSS_PROPERTIES = [
  'hsl(var(--background))',
  'hsl(var(--foreground))',
  'hsl(var(--card))',
  'hsl(var(--card-foreground))',
  'hsl(var(--popover))',
  'hsl(var(--popover-foreground))',
  'hsl(var(--primary))',
  'hsl(var(--primary-foreground))',
  'hsl(var(--secondary))',
  'hsl(var(--secondary-foreground))',
  'hsl(var(--muted))',
  'hsl(var(--muted-foreground))',
  'hsl(var(--accent))',
  'hsl(var(--accent-foreground))',
  'hsl(var(--destructive))',
  'hsl(var(--destructive-foreground))',
  'hsl(var(--border))',
  'hsl(var(--input))',
  'hsl(var(--ring))',
  'hsl(var(--radius))',
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
] as const;

/**
 * Validates chart theme configuration to prevent CSS injection
 * @param config - Chart configuration object
 * @returns Sanitized configuration with only allowed properties
 */
export const sanitizeChartConfig = (config: Record<string, any>): Record<string, any> => {
  const sanitized: Record<string, any> = {};
  
  Object.entries(config).forEach(([key, value]) => {
    if (typeof value === 'object' && value !== null) {
      // Recursively sanitize nested objects
      sanitized[key] = sanitizeChartConfig(value);
    } else if (typeof value === 'string') {
      // Only allow predefined CSS custom properties
      if (ALLOWED_CSS_PROPERTIES.includes(value as any) || 
          /^hsl\(var\(--[a-z0-9-]+\)\)$/.test(value)) {
        sanitized[key] = value;
      } else {
        console.warn(`[CHART_SECURITY] Blocked potentially unsafe CSS value: ${value}`);
        // Use a safe fallback
        sanitized[key] = 'hsl(var(--muted))';
      }
    } else {
      // Non-string, non-object values are generally safe
      sanitized[key] = value;
    }
  });
  
  return sanitized;
};

/**
 * Type guard to check if a value is a safe chart configuration
 * @param config - Configuration to validate
 * @returns True if configuration is safe
 */
export const isValidChartConfig = (config: unknown): config is Record<string, any> => {
  if (typeof config !== 'object' || config === null) {
    return false;
  }
  
  // Additional validation can be added here
  return true;
};
