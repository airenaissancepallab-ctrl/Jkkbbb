import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

import ContactSection from "@/components/ContactSection";
import { 
  Scale, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Shield, 
  Building, 
  Users, 
  FileText, 
  Home,
  Heart,
  Briefcase,
  Copyright,
  Menu,
  X,
  ChevronRight,
  Star,
  ArrowUp,
  MessageCircle,
  Sun,
  Moon
} from 'lucide-react';
import { useTheme } from "next-themes";
import heroImage from '@/assets/supreme-court.jpg';
import lawyerPortrait from '@/assets/lady-justice.jpg';
import legalGavelOffice from '@/assets/legal-gavel-office.jpg';
import supremeCourtGandhi from '@/assets/supreme-court-gandhi.jpg';

const Index = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const practiceAreas = [
    {
      icon: <Scale className="w-8 h-8" />,
      title: "Criminal Law",
      description: "Understanding FIRs, bail applications, IPC offences and criminal procedures.",
      gradient: "from-ruby to-ruby-light",
      shadow: "shadow-premium"
    },
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Family Law",
      description: "Divorce, maintenance, domestic violence, and guardianship matters.",
      gradient: "from-emerald to-emerald-light",
      shadow: "shadow-jewel"
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Constitutional Law",
      description: "Rights-based jurisprudence, Article 21, PILs and constitutional matters.",
      gradient: "from-sapphire to-sapphire-light",
      shadow: "shadow-jewel"
    },
    {
      icon: <Home className="w-8 h-8" />,
      title: "Property Law",
      description: "Land disputes, registration, mutation and property documentation.",
      gradient: "from-amethyst to-amethyst-light",
      shadow: "shadow-jewel"
    },
    {
      icon: <Building className="w-8 h-8" />,
      title: "Legal Drafting",
      description: "Structured pleadings, legal notices and professional documentation.",
      gradient: "from-topaz to-topaz-light",
      shadow: "shadow-gold"
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Legal Research",
      description: "Case law research using SCC Online, Indian Kanoon and legal databases.",
      gradient: "from-rose-gold to-platinum",
      shadow: "shadow-premium"
    }
  ];

  const timeline = [
    {
      year: "2021",
      title: "Enrolled in B.A.LL.B. Course",
      description: "Started integrated law degree at Imamul Hai Khan Law College, Bokaro"
    },
    {
      year: "2022",
      title: "Beginning Court Practice",
      description: "Started gaining practical experience at Purulia District Court"
    },
    {
      year: "2023",
      title: "Legal Research & Documentation",
      description: "Enhanced skills in case law research using SCC Online and Indian Kanoon"
    },
    {
      year: "2024",
      title: "Advanced Legal Training",
      description: "Focusing on constitutional law, criminal procedures, and family law"
    },
    {
      year: "2025",
      title: "Preparing for Legal Career",
      description: "Building foundation for future legal practice and judicial service"
    },
    {
      year: "2028",
      title: "Future Legal Practice",
      description: "Establishing independent legal practice and contributing to justice system"
    }
  ];

  const testimonials = [
    {
      quote: "Pallab's dedication to understanding legal concepts and practical application is impressive. A promising future lawyer.",
      author: "Senior Advocate M. Sharma",
      profession: "Mentor at Purulia Court"
    },
    {
      quote: "His research skills and attention to detail in legal documentation are exceptional for a student.",
      author: "Prof. R. Das",
      profession: "Faculty, Imamul Hai Khan Law College"
    },
    {
      quote: "Pallab combines academic knowledge with practical insight. His commitment to justice is evident.",
      author: "A. Sengupta",
      profession: "Court Clerk, Purulia District Court"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle font-inter relative overflow-hidden">

      {/* Header */}
      <header className="fixed top-0 w-full bg-background/95 backdrop-blur-md border-b border-border z-50 transition-all duration-300">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-rainbow rounded-lg flex items-center justify-center shadow-rainbow">
                <span className="text-white font-playfair font-bold text-xl">PKG</span>
              </div>
              <div className="hidden md:block">
                <h1 className="font-playfair font-semibold text-lg text-foreground gradient-text-gold">Pallab Kumar Gorain</h1>
                <p className="text-sm text-muted-foreground">B.A.LL.B. Student & Legal Intern</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-foreground hover:text-emerald transition-colors">Home</button>
              <button onClick={() => scrollToSection('about')} className="text-foreground hover:text-sapphire transition-colors">About</button>
              <button onClick={() => scrollToSection('services')} className="text-foreground hover:text-amethyst transition-colors">Services</button>
              <button onClick={() => scrollToSection('experience')} className="text-foreground hover:text-ruby transition-colors">Experience</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-foreground hover:text-topaz transition-colors">Testimonials</button>
              <button onClick={() => scrollToSection('contact')} className="text-foreground hover:text-gold transition-colors">Contact</button>
            </nav>

            {/* Right side buttons */}
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="hidden md:flex"
              >
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
              <Button 
                variant="rainbow" 
                size="lg"
                onClick={() => scrollToSection('contact')}
                className="hidden md:flex"
              >
                Book Free Consultation
              </Button>
              
              {/* Mobile menu button */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </Button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 border-t border-border bg-background/95 backdrop-blur-md">
              <nav className="flex flex-col space-y-3">
                <button onClick={() => scrollToSection('home')} className="text-left px-4 py-2 text-foreground hover:text-emerald transition-colors">Home</button>
                <button onClick={() => scrollToSection('about')} className="text-left px-4 py-2 text-foreground hover:text-sapphire transition-colors">About</button>
                <button onClick={() => scrollToSection('services')} className="text-left px-4 py-2 text-foreground hover:text-amethyst transition-colors">Services</button>
                <button onClick={() => scrollToSection('experience')} className="text-left px-4 py-2 text-foreground hover:text-ruby transition-colors">Experience</button>
                <button onClick={() => scrollToSection('testimonials')} className="text-left px-4 py-2 text-foreground hover:text-topaz transition-colors">Testimonials</button>
                <button onClick={() => scrollToSection('contact')} className="text-left px-4 py-2 text-foreground hover:text-gold transition-colors">Contact</button>
                <div className="px-4 pt-2 space-y-3">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                    className="w-full justify-start"
                  >
                    {theme === 'dark' ? <Sun className="w-4 h-4 mr-2" /> : <Moon className="w-4 h-4 mr-2" />}
                    {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
                  </Button>
                  <Button 
                    variant="rainbow" 
                    size="lg"
                    onClick={() => scrollToSection('contact')}
                    className="w-full"
                  >
                    Book Free Consultation
                  </Button>
                </div>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ 
            backgroundImage: `linear-gradient(135deg, rgba(15, 23, 42, 0.8), rgba(15, 23, 42, 0.6)), url(${heroImage})`
          }}
        />
        <div className="relative z-10 container mx-auto px-4 lg:px-6 text-center">
          <div className="max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-6 animate-fade-in bg-gradient-jewel text-white border-none">
              <Scale className="w-4 h-4 mr-2" />
              B.A.LL.B. Student & Legal Intern
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-playfair font-bold text-white mb-6 animate-slide-in-left">
              <span className="gradient-text-sunset">Pallab Kumar</span> <span className="gradient-text">Gorain</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-2xl mx-auto animate-slide-in-right">
              Driven by passion, purpose, and professionalism in India's justice system
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
              <Button variant="sunset" size="xl" onClick={() => scrollToSection('contact')}>
                Schedule Consultation
              </Button>
              <Button variant="outline-gradient" size="xl" onClick={() => scrollToSection('services')}>
                Explore Services
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Mini Feature Strip */}
      <section className="py-8 bg-background border-y border-border">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
            <div className="flex items-center justify-center space-x-3 animate-scale-in">
              <MapPin className="w-6 h-6 text-emerald" />
              <span className="text-foreground font-medium">Practising at Purulia Court</span>
            </div>
            <div className="flex items-center justify-center space-x-3 animate-scale-in">
              <Clock className="w-6 h-6 text-sapphire" />
              <span className="text-foreground font-medium">Student at Imamul Hai Khan Law College</span>
            </div>
            <div className="flex items-center justify-center space-x-3 animate-scale-in">
              <Star className="w-6 h-6 text-ruby" />
              <span className="text-foreground font-medium">B.A.LL.B. (Integrated)</span>
            </div>
            <div className="flex items-center justify-center space-x-3 animate-scale-in">
              <Phone className="w-6 h-6 text-topaz" />
              <span className="text-foreground font-medium">Available for Consultation</span>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-background">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-in-left">
              <div className="relative">
                <img 
                  src={lawyerPortrait} 
                  alt="Advocate Pallab Kumar Gorain" 
                  className="w-full max-w-md mx-auto rounded-2xl shadow-rainbow"
                />
                <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-gradient-rainbow rounded-full flex items-center justify-center animate-float shadow-rainbow">
                  <Scale className="w-12 h-12 text-white" />
                </div>
              </div>
            </div>
            <div className="animate-slide-in-right">
              <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-6">
                <span className="gradient-text">Welcome</span> - <span className="gradient-text-sunset">Namaste!</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                I'm Pallab Kumar Gorain, a committed and enthusiastic law student currently pursuing my B.A.LL.B. degree from Imamul Hai Khan Law College, Bokaro. Alongside my academic journey, I am gaining real-time legal experience by practising at the Purulia District Court, West Bengal.
              </p>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Driven by passion, purpose, and professionalism, I've committed myself to learning and contributing to India's justice system with integrity, empathy, and deep-rooted constitutional values.
              </p>
              <div className="border-l-4 border-gradient-jewel pl-6 mb-8 bg-gradient-to-r from-emerald/10 to-sapphire/10 p-4 rounded-r-lg">
                <p className="text-xl font-playfair italic gradient-text-gold">
                  "Justice is not a service—it's a duty. And I'm here to serve."
                </p>
                <div className="mt-4">
                  <p className="font-semibold text-foreground">Pallab Kumar Gorain</p>
                  <p className="text-muted-foreground">B.A.LL.B. Student, Imamul Hai Khan Law College</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Practice Areas */}
      <section id="services" className="py-20 bg-gradient-subtle">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-4 animate-fade-in">
              <span className="gradient-text">Areas of Legal</span> <span className="gradient-text-sunset">Interest</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in">
              Wide-ranging legal interests with special focus on practical litigation and constitutional law
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {practiceAreas.map((area, index) => (
              <Card key={index} className={`group hover:${area.shadow} transition-all duration-300 hover:-translate-y-2 bg-card border-border animate-scale-in relative overflow-hidden`}>
                <div className="absolute inset-0 bg-gradient-to-br opacity-5 ${area.gradient}"></div>
                <CardHeader className="relative">
                  <div className={`w-16 h-16 bg-gradient-to-r ${area.gradient} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <div className="text-white">
                      {area.icon}
                    </div>
                  </div>
                  <CardTitle className="text-xl font-playfair gradient-text">{area.title}</CardTitle>
                </CardHeader>
                <CardContent className="relative">
                  <CardDescription className="text-base">
                    {area.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Timeline */}
      <section id="experience" className="py-20 bg-background">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-4 animate-fade-in">
              <span className="gradient-text">Academic Journey</span> & <span className="gradient-text-sunset">Court Practice</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in">
              A timeline of academic growth and practical legal experience
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="relative">
              <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 h-full w-0.5 bg-gradient-rainbow"></div>
              
              {timeline.map((item, index) => (
                <div key={index} className={`relative flex items-center mb-12 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} animate-slide-in-left`}>
                  <div className={`flex-1 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'}`}>
                    <Card className="bg-card border-border shadow-card hover:shadow-rainbow transition-all duration-300 relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-jewel opacity-5"></div>
                      <CardHeader className="relative">
                        <div className="flex items-center space-x-4">
                          <Badge variant="secondary" className="bg-gradient-sunset text-white border-none">
                            {item.year}
                          </Badge>
                          <CardTitle className="font-playfair gradient-text">{item.title}</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="relative">
                        <CardDescription className="text-base">
                          {item.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-8 h-8 bg-gradient-rainbow rounded-full border-4 border-background flex items-center justify-center shadow-rainbow">
                    <div className="w-3 h-3 bg-white rounded-full"></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 bg-gradient-subtle">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-4 animate-fade-in">
              <span className="gradient-text">Academic &</span> <span className="gradient-text-sunset">Professional References</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in">
              What mentors and colleagues say about my dedication to legal studies
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-card border-border shadow-card hover:shadow-jewel transition-all duration-300 animate-scale-in relative overflow-hidden">
                <div className={`absolute inset-0 opacity-5 ${index % 3 === 0 ? 'bg-gradient-jewel' : index % 3 === 1 ? 'bg-gradient-sunset' : 'bg-gradient-ocean'}`}></div>
                <CardHeader className="relative">
                  <CardDescription className="text-lg italic">
                    "{testimonial.quote}"
                  </CardDescription>
                </CardHeader>
                <CardContent className="relative">
                  <div className="border-t border-border pt-4">
                    <p className="font-semibold text-foreground gradient-text">{testimonial.author}</p>
                    <p className="text-muted-foreground">{testimonial.profession}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Legal Gallery Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-4 animate-fade-in">
              <span className="gradient-text">Legal Heritage</span> & <span className="gradient-text-sunset">Practice</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in">
              Embracing the rich tradition of Indian judiciary and constitutional values
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="animate-slide-in-left">
              <Card className="overflow-hidden bg-card border-border shadow-elegant hover:shadow-rainbow transition-all duration-300 relative">
                <div className="absolute inset-0 bg-gradient-jewel opacity-5"></div>
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={legalGavelOffice} 
                    alt="Legal Office with Gavel and Justice Symbols" 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-6 relative">
                  <h3 className="text-xl font-playfair font-semibold mb-2 gradient-text">
                    Professional Legal Practice
                  </h3>
                  <p className="text-muted-foreground">
                    Embracing the traditional symbols of justice - the gavel, scales, and constitutional values that guide my legal practice.
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <div className="animate-slide-in-right">
              <Card className="overflow-hidden bg-card border-border shadow-elegant hover:shadow-rainbow transition-all duration-300 relative">
                <div className="absolute inset-0 bg-gradient-sunset opacity-5"></div>
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={supremeCourtGandhi} 
                    alt="Supreme Court of India with Gandhi Statue" 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-6 relative">
                  <h3 className="text-xl font-playfair font-semibold mb-2 gradient-text-sunset">
                    Constitutional Foundation
                  </h3>
                  <p className="text-muted-foreground">
                    Drawing inspiration from the Supreme Court of India and Mahatma Gandhi's principles of truth and non-violence in legal practice.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-12 sm:py-16 lg:py-20 bg-gradient-subtle scroll-mt-24 pb-24">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-8 sm:mb-12 lg:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-playfair font-bold mb-2 sm:mb-4">
              <span className="gradient-text">Let's</span> <span className="gradient-text-sunset">Connect</span>
            </h2>
            <p className="text-base sm:text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto px-4">
              I welcome opportunities for internships, case support, or legal volunteering
            </p>
          </div>

          <ContactSection />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-hero text-primary-foreground py-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-rainbow opacity-10"></div>
        <div className="container mx-auto px-4 lg:px-6 relative">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-rainbow rounded-lg flex items-center justify-center shadow-rainbow">
                  <span className="text-white font-playfair font-bold">PKG</span>
                </div>
                <h3 className="font-playfair font-semibold text-lg gradient-text-gold">Pallab Kumar Gorain</h3>
              </div>
              <p className="text-primary-foreground/80 mb-4">
                Committed law student and legal intern, building a foundation for future legal practice with integrity and dedication.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 gradient-text-sunset">Quick Links</h4>
              <div className="space-y-2">
                <button onClick={() => scrollToSection('about')} className="block text-primary-foreground/80 hover:text-emerald transition-colors">About</button>
                <button onClick={() => scrollToSection('services')} className="block text-primary-foreground/80 hover:text-sapphire transition-colors">Services</button>
                <button onClick={() => scrollToSection('experience')} className="block text-primary-foreground/80 hover:text-ruby transition-colors">Experience</button>
                <button onClick={() => scrollToSection('contact')} className="block text-primary-foreground/80 hover:text-topaz transition-colors">Contact</button>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 gradient-text">Contact Info</h4>
              <div className="space-y-2 text-primary-foreground/80">
                <p>Purulia court, West Bengal</p>
                <p>Student & Legal Intern</p>
                <p>Available for opportunities</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center">
            <p className="text-primary-foreground/60">
              © 2024 Pallab Kumar Gorain. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <Button
          variant="rainbow"
          size="icon"
          className="fixed bottom-20 right-6 z-50 animate-fade-in"
          onClick={scrollToTop}
        >
          <ArrowUp className="w-5 h-5" />
        </Button>
      )}

      {/* WhatsApp Chat Button */}
      <a
        href="https://wa.me/qr/SOTWGEYA74EMM1"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 hidden sm:block"
      >
        <Button
          variant="emerald"
          size="icon"
          className="w-12 h-12 sm:w-14 sm:h-14 rounded-full shadow-lg"
        >
          <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6" />
        </Button>
      </a>
    </div>
  );
};

export default Index;
